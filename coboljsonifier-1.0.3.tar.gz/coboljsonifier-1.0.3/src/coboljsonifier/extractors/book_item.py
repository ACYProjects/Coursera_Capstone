
class BookItem():
    def __init__(self):
        self.type = ""
        self.level = ""
        self.name = ""
        self.format = ""
        self.subformat = ""
        self.decimals = 0
        self.size = 0
        self.start = 0
        self.occurs = None
